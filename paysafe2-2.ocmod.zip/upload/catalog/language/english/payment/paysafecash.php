<?php

$_['payment_title'] = 'Paysafe:cash';
$_['error_payment'] = 'Unfortunately, your payment failed. Please try again';
$_['button_proceed'] = 'Proceed with Paysafe:cash';
$_['payment_description'] = 'Create your barcode and pay your order at a Payment Point in your area. <img src="image/catalog/paysafe_cash.png" alt="Paysafe:cash" title="Paysafe:cash" style="height: 30px">';
