<?php

$_['payment_title'] = 'Paysafe:cash';
$_['error_payment'] = 'Die Zahlung ist leider fehlgeschlagen. Bitte versuchen Sie es noch einmal.';
$_['button_proceed'] = 'Weiter mit Paysafe:cash';
$_['payment_description'] = 'Erstellen Sie Ihren Barcode und bezahlen Sie Ihre Bestellung offline bei der nächstgelegenen Partnerfiliale. <img src="image/catalog/paysafe_cash.png" alt="Paysafe:cash" title="Paysafe:cash" style="height: 30px">';
